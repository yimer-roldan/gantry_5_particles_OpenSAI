# Hero Banner Video - Gantry 5 Particle (Version 2.1.8)

Este repositorio contiene la versión evolucionada del Hero Banner para el ecosistema **OpenSAI**. Esta actualización (v2.1.8) introduce flexibilidad SEO avanzada y un sistema de renderizado blindado.

## 🌟 Novedades de la Versión 2.1.8

* **Jerarquía SEO Dinámica:** Ahora es posible elegir desde el administrador si el título principal debe ser un `<h1>` o un `<h2>`, permitiendo adaptar la partícula a la estructura de cualquier página.
* **Orden Semántico:** El subtítulo se ha fijado como `<h2>` para mantener una estructura lógica y profesional frente a los motores de búsqueda.
* **Ocultación Blindada:** Se implementó una validación por conteo de caracteres (`length > 0`) y limpieza de espacios (`trim`). Esto garantiza que, si los campos de video o botón no tienen contenido real, no se generará código basura en el DOM.

## 🚀 Funcionalidades Principales

* **Mobile First:** Diseño inteligente con flex-box dinámico para dispositivos móviles.
* **Video Pop-up (Lightcase):** Integración nativa para reproducir contenido de YouTube en ventanas emergentes de alta velocidad.
* **Fondo Inteligente:** Soporte para imágenes con anclaje vertical (Top/Center/Bottom) para evitar cortes indeseados en rostros o logos.

## 📁 Instalación

Copiar los archivos `banner_home.yaml` y `banner_home.html.twig` en la ruta:
`/templates/g5_hydrogen/custom/particles/`

> **Requisito:** Es indispensable tener activado el Atom **Lightcase** en la configuración de Atoms de Gantry 5 para el funcionamiento de los pop-ups de video.

## ⚠️ Configuración SEO

Al configurar la partícula, elija la etiqueta del título con responsabilidad:

* Use **H1** si la partícula es el encabezado principal de la landing page.
* Use **H2** si ya existe otro H1 en la página o si la partícula se usa en una sección secundaria.

## 🤝 Contribuciones

Esta versión final liberada está abierta a mejoras. Se invita a los colaboradores a proponer optimizaciones manteniendo siempre la licencia y los estándares de documentación de OpenSAI.

---

**Licencia:** [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/)

**Coautores:** Yimer Roldán & Gemini (Google AI)

**OpenSAI 2026** - *Innovación en Open Business e IA*

---

¿Hay algún otro detalle que quieras incluir en la documentación o estamos listos para cerrar esta versión 2.1.8?